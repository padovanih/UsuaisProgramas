class GenrenciaCadastro{
	
	
	
	
	
	
	
	
}
