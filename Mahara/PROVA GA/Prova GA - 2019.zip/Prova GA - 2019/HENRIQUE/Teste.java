import java.util.Scanner;
import java.util.Random;



class Teste{
	
	
	public static void mostraCatalago(){
		System.out.println("\n --> ESCOLHA A OPÇÃO PELO RESPECTIVO NUMERO:\n");
		System.out.println(" 0 - Sair.");
		System.out.println(" 1 - Inserir um Fabricante.");
		System.out.println(" 2 - Inserir uma Aeronave.");
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		System.out.println("Digite a opção desejada:");
		Scanner in = new Scanner(System.in);
		
		int opcao = in.nextInt();
		
		while (opcao != 0) {
			
			switch (opcao){
				case 1:
					System.out.println("Voce selecionou a primeiro opção.");
					break;
				case 2:
					System.out.println("Você selecionou a segunda opção.");
					break;
				default:
					System.out.println("ERRO: código inválido, favor confira a opção desejada.");
					break;
			}
			
			
		}
		
		
		
		
		
		
		
		
	}
	
	
	
	
}
