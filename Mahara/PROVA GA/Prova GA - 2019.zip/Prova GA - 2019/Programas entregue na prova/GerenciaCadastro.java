public class GerenciaCadastro
{
	private Fabricante [] fabricantes;
	private Aeronave [] aeronaves;
	private int totAero;
	private int totFabri;
	
	
	public GerenciaCadastro()
	{
		this.fabricantes = new Fabricante [10];
		this.aeronaves = new Aeronave [10];
		this.totAero = 0;
		this.totFabri = 0;
	}
	
	//Get's
	public Aeronave [] get_aeronave(){return aeronaves;}
	public Fabricante [] get_fabricantes(){return fabricantes;}
	public int get_totAero(){return totAero;}
	public int get_totFabri(){return totFabri;}
	
	public void insere_elemento(String nome_aeron, String mod, String matricula, String nome_fabricante)
	{
		//percorre o array de fabricantes cadastrados
		for (int i = 0; i < totFabri; i++)
		{
			//array de fabricantes cadastrados e pega o nome de cada um 
			Fabricante [] fabri = fabricantes[i].get_nome_fab();
			//cria uma variavel pra pegar o codigo internacional do fabricante
			int codigo_internacional = fabricantes[i].get_cod_internacional();
			//printa na tela todos fabricantes cadastrados
			System.out.println(fabricantes[i].get_nome_fab());
		}
		for (int j = 0; j < totAero; j++)
		{
			if (nome_fabricante == fabri[j].get_nome_fab())
			{
				aeronaves[j] = new Aeronave(nome_aero, modelo,matricula,codigo_internacional);
			}
		}
		
		
		
		
		
		
	}
	
	public void cadastra_fabricante(String nome_fabr,String pais, int cod_I)
	{
		fabricantes[totFabri] = new Fabricante(nome_fabr,pais,cod_I);
	}
}
