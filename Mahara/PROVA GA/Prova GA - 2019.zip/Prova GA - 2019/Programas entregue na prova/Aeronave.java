import java.util.Random;

public class Aeronave implements ChaveId
{
	 private int chaveId;
	 private String nome_aero;
	 private String modelo;
	 private String matricula;
	 private int cod_inter;
	 
	 public Aeronave(String nome, String modelo, String matricula, int cod_inter)
	 {
		this.nome_aero = nome;
		this.modelo = modelo;
		this.matricula = matricula;
		this.cod_inter = cod_inter;
	 }
	
	public String get_nome_aero(){return nome_aero;}
	public String get_modelo(){return modelo;}
	public String get_matricula(){return matricula;}
	public int get_cod_inter(){return cod_inter;}
	
	public int geraChaveId()
	{
		Random gerador = new Random();
		 for (int i = 1; i < 10000; i++)
		 {
			chaveId = gerador.nextInt(10001);
		 }
		 return chaveId;
	}
}
