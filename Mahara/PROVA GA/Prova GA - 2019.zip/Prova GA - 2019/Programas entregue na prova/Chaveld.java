public interface Chaved
{
public int geraChaveId();
}
