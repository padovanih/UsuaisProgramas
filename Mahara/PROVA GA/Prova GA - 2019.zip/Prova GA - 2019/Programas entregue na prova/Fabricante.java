import java.util.Random;


public class Fabricante implements ChaveId
{
	private int chaveId1;
	private String nome_fabr;
	private String pais;
	private int cod_intern;
	
	
	public Fabricante(String nome, String pais, int cod_Inter)
	{
		this.nome_fabr = nome;
		this.pais = pais;
		this.cod_intern = cod_Inter;
	}
	
	
	//GET'S
	public String get_nome_fab(){return nome_fabr;}
	public String get_pais(){return pais;}
	public int get_cod_internacional(){return cod_intern;}
	
	
	public int geraChaveId()
	{
		Random gerador = new Random();
		 for (int i = 1; i < 10000; i++)
		 {
			chaveId1 = gerador.nextInt(10001);
		 }
		 return chaveId1;
	}
}
