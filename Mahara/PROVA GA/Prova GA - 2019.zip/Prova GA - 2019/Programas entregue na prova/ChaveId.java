public interface ChaveId
{
public int geraChaveId();
}
