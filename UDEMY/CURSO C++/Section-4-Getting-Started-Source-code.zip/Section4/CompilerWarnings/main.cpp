#include <iostream>

int main() {
    
    int favorite_number;
    
    std::cout << "Hello world" << std::endl;
    return 0;
}

