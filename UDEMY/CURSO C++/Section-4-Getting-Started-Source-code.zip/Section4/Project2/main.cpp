#include <iostream>

int main() {
    std::cout << "Hello Project 2" << std::endl;
    return 0;
}
