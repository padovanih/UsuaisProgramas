#include <iostream>

int main() {
    std::cout << "Hello Project 1" << std::endl;
    return 0;
}

